{{-- BEGIN: Buy Now --}}
<div class="buy-now">
    <a href="https://1.envato.market/vuexy_admin" target="_blank" class="btn btn-danger">Buy Now</a>
</div>
{{-- End: Buy Now --}}
