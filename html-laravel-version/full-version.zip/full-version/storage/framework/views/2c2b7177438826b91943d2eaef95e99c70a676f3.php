<?php $__env->startSection('title', 'Error 500'); ?>

<?php $__env->startSection('page-style'); ?>
        
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/pages/error.css'))); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- error 500 -->
<section class="row flexbox-container">
  <div class="col-xl-7 col-md-8 col-12 d-flex justify-content-center">
    <div class="card auth-card bg-transparent shadow-none rounded-0 mb-0 w-100">
      <div class="card-content">
        <div class="card-body text-center">
          <img src="<?php echo e(asset('images/pages/500.png')); ?>" class="img-fluid align-self-center" alt="branding logo">
          <h1 class="font-large-2 mt-1 mb-0">Internal Server Error!</h1>
          <p class="p-3">
            susceptive nonturbinated indoctrination formulary dyskinetic deafforest Strumella frolicsomeness encrustment
            portia myelination lachrymatory bestain hoople piscator pyramidoidal parter clipt.
          </p>
          <a class="btn btn-primary btn-lg" href="dashboard-analytics">Back to Home</a>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- error 500 end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/fullLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-admin/vuexy-html-laravel-template/resources/views//pages/error-500.blade.php ENDPATH**/ ?>